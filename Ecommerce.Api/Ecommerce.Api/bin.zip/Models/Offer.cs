﻿namespace Ecommerce.Api.Models
{
    public class Offer
    {
        public int OfferId { get; set; }
        public string Title { get; set; } = "";
        public int Discount { get; set; } = 0;

    }
}
