﻿namespace Ecommerce.Api.Models.Dto
{
    public class RevokeTokenDto
    {
        public string token { get; set; }
    }
}
