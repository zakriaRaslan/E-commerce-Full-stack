﻿namespace Ecommerce.Api.Models.Dto
{
    public class UserRole
    {
        public const string User = "User";
        public const string Admin = "Admin";

    }
}
